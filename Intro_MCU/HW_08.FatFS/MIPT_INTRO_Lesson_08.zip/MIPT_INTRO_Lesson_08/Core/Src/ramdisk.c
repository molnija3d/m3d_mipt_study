/*
 * ramdisk.c
 *
 *  Created on: Feb 5, 2025
 *      Author: EZ-GPRO
 */
#include "ramdisk.h"


uint8_t ramdisk[SECT_CNT][SECT_SZ];
