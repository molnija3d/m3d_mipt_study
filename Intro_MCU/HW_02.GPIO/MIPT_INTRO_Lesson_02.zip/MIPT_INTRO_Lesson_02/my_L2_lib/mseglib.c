/*
 * 7seglib.c
 *
 *  Created on: Jan 14, 2025
 *      Author: EZ-GPRO
 */
#include "mseglib.h"
#include "main.h"

volatile int counter = 0;

static int flag = -1;
static MY_7SEG disp = { };

void static set_pos(int pos);
void static print_digit(int num);
void static print_letter(char letter);
/**
 * @brief  This function make initialization of the lib
 * @retval flag {0,1}.
 */
int my_7seg_init(MY_7SEG seg) {
	flag = 1;
	if (seg.A.pin && seg.A.port) {
		disp.A = seg.A;
	} else {
		flag = 0;
	}
	if (seg.B.pin && seg.B.port) {
		disp.B = seg.B;
	} else {
		flag = 0;
	}
	if (seg.C.pin && seg.C.port) {
		disp.C = seg.C;
	} else {
		flag = 0;
	}
	if (seg.D.pin && seg.D.port) {
		disp.D = seg.D;
	} else {
		flag = 0;
	}
	if (seg.E.pin && seg.E.port) {
		disp.E = seg.E;
	} else {
		flag = 0;
	}
	if (seg.F.pin && seg.F.port) {
		disp.F = seg.F;
	} else {
		flag = 0;
	}
	if (seg.G.pin && seg.G.port) {
		disp.G = seg.G;
	} else {
		flag = 0;
	}
	if (seg.P.pin && seg.P.port) {
		disp.P = seg.P;
	} else {
		flag = 0;
	}
	if (seg.Q1.pin && seg.Q1.port) {
		disp.Q1 = seg.Q1;
	} else {
		flag = 0;
	}
	if (seg.Q2.pin && seg.Q2.port) {
		disp.Q2 = seg.Q2;
	} else {
		flag = 0;
	}
	if (seg.Q3.pin && seg.Q3.port) {
		disp.Q3 = seg.Q3;
	} else {
		flag = 0;
	}
	return flag;
}

/**
 * @brief this function print nums to 7seg indicator
 * @retval none
 */

void my_7seg_disp_num(int num) {
	if (flag) {
		for (int pos = 0; pos < 3; pos++) {
			set_pos(-1);
			print_digit(num % 10);
			set_pos(pos);
			HAL_Delay(1);
			num /= 10;
		}

	}
}

/**
 * @brief this function enables specified segment
 * pos = 0, 1, 2 - enable Q1, Q2, Q3. Any other - disable all.
 * @retval none
 */
void static set_pos(int pos) {
	switch (pos) {
	case 2:
		HAL_GPIO_WritePin(disp.Q1.port, disp.Q1.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.Q2.port, disp.Q2.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.Q3.port, disp.Q3.pin, GPIO_PIN_RESET);
		break;
	case 1:
		HAL_GPIO_WritePin(disp.Q1.port, disp.Q1.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.Q2.port, disp.Q2.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.Q3.port, disp.Q3.pin, GPIO_PIN_RESET);
		break;
	case 0:
		HAL_GPIO_WritePin(disp.Q1.port, disp.Q1.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.Q2.port, disp.Q2.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.Q3.port, disp.Q3.pin, GPIO_PIN_SET);
		break;
	default:
		HAL_GPIO_WritePin(disp.Q1.port, disp.Q1.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.Q2.port, disp.Q2.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.Q3.port, disp.Q3.pin, GPIO_PIN_RESET);
		break;
	}
}

/**
 * @brief this function print digit to 7seg indicator
 * @retval none
 */

void static print_digit(int num) {
	switch (num) {
	case 0:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 1:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 2:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 3:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 4:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 5:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 6:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 7:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 8:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	case 9:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	default:
		HAL_GPIO_WritePin(disp.A.port, disp.A.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.B.port, disp.B.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.C.port, disp.C.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.D.port, disp.D.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.E.port, disp.E.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.F.port, disp.F.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.G.port, disp.G.pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(disp.P.port, disp.P.pin, GPIO_PIN_RESET);
		break;
	}
}

/**
 * @brief this function print available chars to 7seg
 * @retval none
 */
void my_7seg_disp_char(char letter, int pos) {
	if (flag) {
		switch (pos) {
		case 0:
			print_letter(letter);
			break;
		case 1:
			print_letter(letter);
			break;
		case 2:
			print_letter(letter);
			break;
		}
	}
}

/**
 * @brief this function print letter to 7-seg indicator
 * @retval none
 */
void static print_letter(char letter) {

}

/**
 * @brief this function runs animation at 7-seg display
 * @retval none
 */
void my_7seg_disp_anim(int num) {

}

/**
 * @brief external interrupt to handle two buttons
 * @retval none
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	switch (GPIO_Pin) {
	case BTN_1_Pin:
		if (counter < 999) {
			counter++;
		} else {
			counter = 0;
		}
		break;
	case BTN_2_Pin:
		if (counter > 0) {
			counter--;
		} else {
			counter = 999;
		}
		break;
	};
}
