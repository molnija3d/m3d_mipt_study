/*
 * my_pid.c
 *
 *  Created on: Feb 20, 2025
 *      Author: EZ-GPRO
 */
#include "my_pid.h"

/**
  * @brief simple PID regulator
  * @retval calculated out value in range [min, max]
  */
int my_PID(int target, int feedback, int min, int max)
{
    int dU = (int)target - (int)feedback;
	static int prev_dU = 0;
	static float int_part = 0;

	static float kP = 0.15f;
	static float kI = 0.015f;
	static float kD = 0.005f;

	int_part += dU * kI;

	if (int_part < min)
	{
		int_part = min;
	}
	if (int_part > max)
	{
		int_part = max;
	}

	int out = dU * kP + int_part + kD * (dU - prev_dU);
	prev_dU = dU;

	if (out < min)
	{
		out = min;
	}
	if (out > max)
	{
		out = max;
	}
	return out;
}

