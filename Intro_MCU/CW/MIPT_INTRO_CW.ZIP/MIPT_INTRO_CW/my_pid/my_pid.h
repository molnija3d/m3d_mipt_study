/*
 * my_pid.h
 *
 *  Created on: Feb 20, 2025
 *      Author: EZ-GPRO
 */
#ifndef INC_MY_PID_H_
#define INC_MY_PID_H_

#include "stdint.h"

int my_PID(int target, int feedback, int min, int max);

#endif /* INC_FEEDBACK_H_ */
