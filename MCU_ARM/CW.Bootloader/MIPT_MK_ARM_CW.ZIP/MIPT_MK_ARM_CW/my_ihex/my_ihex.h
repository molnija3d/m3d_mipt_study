/*
 * my_ihex.h
 *
 *  Created on: Apr 6, 2025
 *      Author: EZ-GPRO
 */

#ifndef MY_IHEX_H_
#define MY_IHEX_H_
#include "inttypes.h"

typedef struct {
	uint8_t data[16];
	uint8_t type;
	uint8_t size;
	uint16_t addrh;
	uint16_t addrl;
} my_record;

int check_ihex(const char *ihex);
uint8_t str_to_uint8(const char *str);
int write_to_flash(const my_record *data);
int proc_ihex(const char *my_flash[], uint8_t size);
static uint32_t GetPage(uint32_t Addr);

#endif /* MY_IHEX_H_ */
