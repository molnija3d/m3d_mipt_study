/*
 * my_ihex.c
 *
 *  Created on: Apr 6, 2025
 *      Author: EZ-GPRO
 */

/**
 * @brief  This function calculate if ihex string is ok.
 * max data length is limited to 16 bytes per one hex string.
 * @retval control sum
 */
#include "my_ihex.h"
#include "main.h"
#include "cmsis_gcc.h"

int check_ihex(const char *ihex) {
	uint8_t i = 0, sum = 0;

	if (ihex[i++] == ':') {
		while (ihex[i] != 0 && i < 44) {
			sum += str_to_uint8(ihex + i);
			i += 2;
		}
		sum = 0x1u + ~sum;
	}

	return sum;
}
/**
 * @brief  This function calculates hex val of a two char symbols
 * @retval hex val in uint8_t
 */
uint8_t str_to_uint8(const char *str) {
	uint8_t uint8 = 0;
	uint8 = str[0] > '9' ? str[0] - '7' : str[0] - '0';
	uint8 <<= 4;
	uint8 |= 0xF & (str[1] > '9' ? str[1] - '7' : str[1] - '0');
	return uint8;
}
/**
 * @brief  This function erases corresponding flash pages
 * @retval hex val in uint8_t
 */
int erase_flash(const my_record *data) {
	uint32_t FirstPage = 0, NbOfPages = 0;
	uint32_t Address = 0, PageError = 0;
	FLASH_EraseInitTypeDef EraseInitStruct;
       Address = data->addrh << 16 | (0xff & data->addrl);
	  HAL_FLASH_Unlock();
	  __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPTVERR);
	  /* Get the 1st page to erase */
	    FirstPage = GetPage(Address);
	    /* Get the number of pages to erase from 1st page */
	   NbOfPages = 1;

	    /* Fill EraseInit structure*/
	    EraseInitStruct.TypeErase   = FLASH_TYPEERASE_PAGES;
	    EraseInitStruct.Page        = FirstPage;
	    EraseInitStruct.NbPages     = NbOfPages;

	    HAL_FLASHEx_Erase(&EraseInitStruct, &PageError);
	    HAL_FLASH_Lock();

	 return 0;

}

/**
 * @brief  This function perform writing to flash. Flash should be erased before.
 * @retval hex val in uint8_t
 */
int write_to_flash(const my_record *data){
	uint32_t Address = 0;
	 Address = data->addrh << 16 | (0xff & data->addrl);
	HAL_FLASH_Unlock();
	__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_OPTVERR);
    for(uint8_t i = 0; i < 2; i++){
    	HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, Address + 8*i, *((uint64_t *) (data->data) + i));
    }
    HAL_FLASH_Lock();
    return 0;
}
/**
  * @brief  Gets the page of a given address
  * @param  Addr: Address of the FLASH Memory
  * @retval The page of a given address
  */
static uint32_t GetPage(uint32_t Addr)
{
  return (Addr - FLASH_BASE) / FLASH_PAGE_SIZE;;
}

/**
 * @brief  This function process ihex buffer
 * @retval 0 - ok
 */
int proc_ihex(const char *my_flash[], uint8_t size) {
	my_record data = { 0 };
	for (uint8_t i = 0; i < size; i++) {
		/*
		 *":02 0000 04 0804 EE",
		 *":10 0000 00 00800020B50304083103040839030408 04",
		 *":10 0010 00 41030408490304085103040800000000 D8",
		 *":10 0020 00 00000000000000000000000059030408 68",
		 *":10 0030 00 67030408000000007503040883030408 34",
		 *":10 0040 00 05040408050404080504040805040408 5C",
		 *":10 0050 00 05040408050404080504040805040408 4C",
		 *":04 1284 00 FD010408 5C",
		 *":04 1288 00 D9010408 7C",
		 *":0C 128C 00 0024F4001000000001000000 2D",
		 *":04 0000 05 080403B5 33",
		 *":00 0000 01 FF"
		 */
		if (check_ihex(my_flash[i]) == 0) {
			data.size = str_to_uint8(my_flash[i] + 1);
			data.type = str_to_uint8(my_flash[i] + 7);
			switch (data.type) {
			case 00:
				/*data record*/
				if (data.addrh) {
					data.addrl = str_to_uint8(my_flash[i] + 3) << 8;
					data.addrl |= 0xFF & str_to_uint8(my_flash[i] + 5);
					for (uint8_t j = 0; j < data.size; j++) {
						data.data[j] = str_to_uint8(my_flash[i] + 9 + 2 * j);
					}
					write_to_flash(&data);

				} else {
					/* error there should be 04 record before 00*/

				}
				break;

			case 01:
				/*end of ihex*/
				__NOP();
				break;

			case 04:
				/*address record*/
				if (!data.addrh) {
					data.addrh = str_to_uint8(my_flash[i] + 9) << 8;
					data.addrh |= 0xFF & str_to_uint8(my_flash[i] + 11);
					erase_flash(&data);
				} else {
					/* error there should be only one 04 record*/

				}
				break;
			}
		}
	}

	return 0;
}
