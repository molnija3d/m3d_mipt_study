/*
 * my_psu.h
 *
 *  Created on: Feb 20, 2025
 *      Author: EZ-GPRO
 */
#ifndef MY_PSU_H_
#define MY_PSU_H_
#include "main.h"

#define vext (5000)
/* for 3.3v psu
* #define vext (3300)
*/

#define MAX_ADC (99)
#define fA (32)
#define fB (32)
#define fK (6)
/*
 * filter = (fA * filter + fB*signal) >> fK;
 * fk = 1, 2, 3...
 * fA + fB = 2^fK
 */

extern ADC_HandleTypeDef hadc1;
extern SPI_HandleTypeDef hspi2;
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim4;

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim);
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
void display(void);
void run_PID();
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc);
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc);
void init_my_psu();

#endif /* MY_PSU_H_ */

