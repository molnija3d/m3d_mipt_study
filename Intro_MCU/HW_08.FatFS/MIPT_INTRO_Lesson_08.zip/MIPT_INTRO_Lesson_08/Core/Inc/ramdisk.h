/*
 * ramdisk.h
 *
 *  Created on: Feb 5, 2025
 *      Author: EZ-GPRO
 */

#ifndef INC_RAMDISK_H_
#define INC_RAMDISK_H_

#include "stdint.h"

#define SECT_SZ (512U)
#define SECT_CNT (68U)
#define CLEAN_FS ((void *)0x8020000)
extern uint8_t ramdisk[SECT_CNT][SECT_SZ];

#endif /* INC_RAMDISK_H_ */
