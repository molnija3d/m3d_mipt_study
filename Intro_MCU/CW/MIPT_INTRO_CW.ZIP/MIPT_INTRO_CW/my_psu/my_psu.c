/*
 * my_psu.c
 *
 *  Created on: Feb 20, 2025
 *      Author: EZ-GPRO
 */
#include "st7789.h"
#include "stdio.h"
#include "my_tasks.h"
#include "my_pid.h"
#include "my_psu.h"
#include "stm32f4xx_hal_conf.h"

static char buffer[128] = {0,};

static volatile uint32_t enc_cnt = 0;
static volatile int dir = 0;
static volatile int capture = 0;
static volatile int btn_psh = 0;

static volatile uint32_t vset_mv = 0;
static volatile uint32_t vref = 0;
static volatile uint32_t vout = 0;
static volatile uint32_t iout = 0;

static volatile uint32_t adcv = 0;
static volatile uint32_t adci = 0;

/**
 * @brief making all needed init
 * @retval none
 */
void init_my_psu() {
	ST7789_Init();
	ST7789_Fill_Color(BLACK);
	HAL_GPIO_WritePin(TFT_BLK_GPIO_Port, TFT_BLK_Pin, GPIO_PIN_SET);
	HAL_TIM_Encoder_Start_IT(&htim4, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
	HAL_TIM_Base_Start(&htim2);
	HAL_ADC_Start_IT(&hadc1);
	HAL_ADCEx_InjectedStart_IT(&hadc1);
	task_add(display);
	task_add(run_PID);
	tasks_start();
}

/**
 * @brief output data to spi display
 * @retval none
 */
void display(void) {
	/*
	 * vref = 1200mv
	 * 151k/100k - resistive divider
	 * vext - defined value of external voltage supply
	 * 3300mv - maximum output value of divider
	 * vext /3300 *(1200 * 151/100) = 1812
	 * 1805 - adjusted with using external multimeter
	 */
	vout = (vext/3300) * (adcv * 1805) / vref;

	/*
	 * there is usid 0.5 ohm resistor to measure current
	 * 950 coeff was adopted with using external multimeter
	 */
	iout = (adci * 950) / vref;

	sprintf(buffer, "Vset: %lu.%03luv", vset_mv / 1000, vset_mv % 1000);
	ST7789_WriteString(10, 240 - 4 * 26, buffer, Font_16x26, YELLOW, BLACK);

	sprintf(buffer, "Vout: %lu.%03luv", vout / 1000, vout % 1000);
	ST7789_WriteString(10, 240 - 3 * 26, buffer, Font_16x26, YELLOW, BLACK);

	sprintf(buffer, "Iout: %lu.%03luma", iout / 1000, iout % 1000);
	ST7789_WriteString(10, 240 - 2 * 26, buffer, Font_16x26, YELLOW, BLACK);

	sprintf(buffer, "PWM:  %3lu",
			(100 * __HAL_TIM_GET_COMPARE(&htim1, TIM_CHANNEL_1)) / 1000);
	ST7789_WriteString(10, 240 - 26, buffer, Font_16x26, YELLOW, BLACK);
	task_delay(200);
}

/**
 * @brief running PID regulation
 * @retval non
 */
void run_PID() {
	vout = (vext/3300) * (adcv * 1805) / vref;
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, my_PID(vset_mv, vout, 0, 1000));
	task_delay(2);
}

/**
 * @brief geting encoder position
 * @retval none
 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim) {
	if (htim->Instance == TIM4 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1) {
		enc_cnt = __HAL_TIM_GET_COUNTER(htim);
		//dir = __HAL_TIM_IS_TIM_COUNTING_DOWN(htim);
		vset_mv = (vext * enc_cnt) / 100;
	}
}

/**
 * @brief getting encoder push button action
 * @retval none
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
	if (GPIO_Pin == BTN_Pin) {
		btn_psh = 1;
	}
}

/**
 * @brief regular ADC conversion callback
 * @retval
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
	/* Prevent unused argument(s) compilation warning */
	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
	/*
	 filt = (A * filt + B*signal) >> k;
	 k = 1, 2, 3...
	 A + B = 2^k
	 */
	if (hadc == &hadc1) {
		adcv = (fA * adcv + fB * HAL_ADC_GetValue(&hadc1)) >> fK;
	}

	HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
}

/**
 * @brief
 * @retval
 */
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc) {
	HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
	if (hadc == &hadc1) {
		adci = (fA * adci
				+ fB * HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_1))
				>> fK;
		vref = (fA * vref
				+ fB * HAL_ADCEx_InjectedGetValue(&hadc1, ADC_INJECTED_RANK_2))
				>> fK;
	}
	HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
}

