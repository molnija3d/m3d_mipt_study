/*
 * spi_ws2812.h
 *
 *  Created on: May 24, 2025
 *      Author: EZ-GPRO
 */
#include <inttypes.h>
#ifndef SPI_WS2812_H_
#define SPI_WS2812_H_

typedef struct {
	uint8_t g[8];
	uint8_t r[8];
	uint8_t b[8];
} color_bit_t;

typedef enum {
	C_RESET = -1, C_ZERO, C_RED, C_GREEN, C_BLUE
} my_colors;


#define LEDCNT 104

void fill_color(uint16_t led_num, uint8_t bright, my_colors color);
#endif /* SPI_WS2812_H_ */
