/*
 * my_plc.h
 *
 *  Created on: Apr 30, 2025
 *      Author: EZ-GPRO
 */

#ifndef MY_PLC_H_
#define MY_PLC_H_

#define usrLedPort(arg) LED##arg##_GPIO_Port
#define usrLedPin(arg) LED##arg##_Pin
#define usrBtnPort(arg) BTN##arg##_GPIO_Port
#define usrBtnPin(arg) BTN##arg##_Pin
#define usrPORT_CNT 4
#define userCOMMANDS 5

/*Base data type*/
typedef struct {
	uint16_t id;   //Output port ID (LED port)
	uint16_t mask; //Input mask (Button mask)
	uint16_t and;  //Mask condition (OR/AND)
} Parameters_T;

/*Data structure to send via Queue*/
typedef struct {
	uint32_t *data; //Data pointer
	uint8_t size;   //Data size
	uint8_t cmd;    //Command
} QDATA_T;

/*Data structure to observe stack values*/
typedef struct{
UBaseType_t TransmitUSB;
UBaseType_t ProcessUSBdata;
UBaseType_t I2C;
UBaseType_t Buttons;
UBaseType_t LED;
UBaseType_t Sync;
} HightStack_T;

/*Available commands*/
typedef enum {
	C_NONE = 0U, C_SET, C_SAVE, C_LOAD, C_SHOW, C_STATUS, C_RESET
} COMMANDS_t;



void StartProcessUSBdata(void const * argument);
void StartButtons(void const * argument);
void StartLED(void const * argument);
void StartSync(void const * argument);
void StartI2C(void const * argument);
extern osMessageQId SyncQueueHandle;
extern osMessageQId I2C_QueueHandle;

extern osSemaphoreId userDataRecievedHandle;
extern osSemaphoreId usrSendBufAvailHandle;

extern osMutexId mutexI2CHandle;
extern osMutexId mutexUSBHandle;



extern osThreadId myLED1Handle;
extern osThreadId myLED2Handle;
extern osThreadId myLED3Handle;
extern osThreadId myLED4Handle;
extern  osThreadId mySyncHandle;
extern  osThreadId myI2CHandle;
extern  osThreadId myTransmitUSBHandle;




void vUserPrintHelp(void);

#endif /* MY_PLC_H_ */
