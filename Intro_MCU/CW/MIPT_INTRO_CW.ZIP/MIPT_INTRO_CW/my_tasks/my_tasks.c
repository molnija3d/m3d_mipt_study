/*
 * my_tasks.c
 *
 *  Created on: Feb 10, 2025
 *      Author: EZ-GPRO
 */
#include "my_tasks.h"

static uint32_t t_delays[MAX_TASKS] = { 0, };
static uint32_t t_time[MAX_TASKS] = { 0, };
static task_t tasks[MAX_TASKS] = { 0, };
static uint32_t current_task = 0;
static uint32_t task_q = 0;

extern uint32_t HAL_GetTick(void);

/**
 * @brief running tasks
 * @param None
 * @retval None
 */
void tasks_start() {
	while (1) {
		for (current_task = 0; current_task < task_q; current_task++) {
			if (HAL_GetTick() - t_time[current_task] > t_delays[current_task]) {
				tasks[current_task]();
				t_time[current_task] = HAL_GetTick();
			}
		}
	}
}

/**
 * @brief setting a delay for current task
 * @param uint32_t delay in ms
 * @retval None
 */
void task_delay(uint32_t delay) {
	t_delays[current_task] = delay;
}

/**
 * @brief force zero delay for specified task to run it as soon as possible
 * @param uint32_t task_num - task number
 * @retval None
 */
tres_t task_force(uint32_t task_num) {
	t_delays[task_num] = 0;
	return TASK_OK;
}

/**
 * @brief add new task for running
 * @param task_t my_task - pointer to function (void func())
 * @retval error code
 */
tres_t task_add(task_t my_task) {
	if (my_task && task_q < MAX_TASKS - 1) {
		tasks[task_q] = my_task;
		task_q++;
		return TASK_OK;
	} else if (!my_task) {
		return TASK_FAIL;
	}
	return TASK_FULL;
}
/**
 * @brief get value from queue
 * @param queue_t *qe - pointer to queue, int *data - pointer to data to be putted
 * @retval error code
 */
qres_t q_get(queue_t *qe, int *data) {
	if (qe->q_len) {
		*data = qe->data[qe->start];
		qe->start < Q_LEN - 1 ? qe->start++ : (qe->start = 0);
		qe->q_len--;
		if (!qe->q_len) {
			qe->start = 0;
			qe->end = 0;
		}
		return Q_OK;
	} else {
		return Q_NONE;
	}
	return Q_FAIL;
}

/**
 * @brief put value from queue
 * @param queue_t *qe - pointer to queue, int data a value to be putted to queue
 * @retval error code
 */
qres_t q_put(queue_t *qe, int data) {
	if (qe->q_len < Q_LEN - 1) {
		qe->data[qe->end] = data;
		qe->q_len++;
		qe->end < Q_LEN - 1 ? qe->end++ : (qe->end = 0);
		return Q_OK;
	} else {
		return Q_FULL;
	}
	return Q_FAIL;
}

/**
 * @brief check if there is any data in queue
 * @param queue_t *qe - pointer to queue
 * @retval error code
 */
qres_t q_check(queue_t *qe) {
	if (qe->q_len) {
		return Q_RDY;
	}
	return Q_NONE;
}
