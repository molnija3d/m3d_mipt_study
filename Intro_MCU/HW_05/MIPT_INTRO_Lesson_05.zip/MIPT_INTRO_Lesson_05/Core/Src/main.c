/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_cdc_if.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint32_t usb_recv_flag = 0;
char ibuf[256] = { 0, };
char obuf[256] = { 0, };
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void SystemClock_Config(void);
void print_to_ihex(void *addr, uint32_t len);
void print_to_ihex_pf(void *addr, uint32_t len);
void u8_to_hex(char *buff, uint8_t byte);
void u16_to_hex(char *buff, uint16_t word);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**
 * @brief  This function implements write operation to USB CDC device
 * instead of standart output
 * @retval int len
 */
int _write(int file, uint8_t *data, uint16_t len) {
	CDC_Transmit_FS(data, len);
	return len;
}

/**
 * @brief  This function implements write operation to USB CDC device
 * instead of standart output
 * @retval int ch
 */
/*
 int __io_putchar(int ch){
 CDC_Transmit_FS((uint8_t *)&ch, 1);
 return ch;
 }
 */
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USB_DEVICE_Init();
	/* USER CODE BEGIN 2 */

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		if (usb_recv_flag > 0) {
			usb_recv_flag = 0;
			char cmd[64] = { 0, };
			uint32_t hex_addr = 0, hex_bytes = 0;
			//clear output buffer
			memset(obuf, 0, 256);
			//simple scanning a command
			sscanf(ibuf, "%s %lx %lu", cmd, &hex_addr, &hex_bytes);
			if (!strcmp(cmd, "get_hex")) {
				print_to_ihex((void*) hex_addr, hex_bytes); //using byte_to_hex instead of sprintf
				//print_to_ihex_pf((void*) hex_addr, hex_bytes);  //using sprintf to make out_buffer
			} else {
				//echo help
				printf("Usage: get_hex [address] [bytes]	get specified count of [bytes] from memory at [address]\nExample: get_hex 8000000 64\n");
			}
		}
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = 16;
	RCC_OscInitStruct.PLL.PLLN = 192;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = 4;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}
/* USER CODE BEGIN 4 */
/**
 * @brief  prints ASCII HEX byte value to hex buffer
 * @retval none
 */
void u8_to_hex(char *buff, uint8_t byte) {
	const char hex[] = "0123456789ABCDEF";
	buff[0] = hex[(byte >> 4) & 0xF];
	buff[1] = hex[byte & 0xF];
}
/* USER CODE BEGIN 4 */
/**
 * @brief  prints ASCII HEX u16 value to hex buffer
 * @retval none
 */
void u16_to_hex(char *buff, uint16_t word) {
	u8_to_hex(buff, (word >> 8) & 0xFF);
	u8_to_hex(buff + 2, word & 0xFF);
}

/* USER CODE BEGIN 4 */
/**
 * @brief  This function prints to USB CDC device an ihex array
 * using byte_to_hex function
 * @retval none
 */
void print_to_ihex(void *addr, uint32_t len) {
	//printing Extended Segment Address Record to ASCII codes
	uint16_t tmp = (uint16_t) (((uint32_t) addr) >> 16);
	uint8_t checksum = 0;

	char my_buf[45] = "\n:02000004";
	u16_to_hex(&my_buf[10], tmp);
	checksum = 0x1u + ~(6u + (tmp >> 8 & 0xff) + (tmp & 0xff));
	u8_to_hex(&my_buf[14], checksum);
	my_buf[16] = '\n';

	CDC_Transmit_FS((uint8_t*) my_buf, 17);

	//printing Data record to ASCII
	int i = 0;
	do {
		checksum = 0;
		my_buf[0] = ':';
		//printing a segment address in ASCII at positions my_buf[3..8]
		//my_buf[1] and my_buf[2] stores byte count in ASCII
		tmp = (uint16_t)((uint32_t)(addr + i)) ;
		checksum += tmp;
		checksum += tmp >> 8;
		u16_to_hex(&my_buf[3], tmp);

		//TYPE 00
		tmp = 0x0u;
		u8_to_hex(&my_buf[7], tmp);

		//printing HEX bytes in ASCII (positions my_buf[9...])
		do {
			tmp = *(((uint8_t*) addr) + i);
			checksum += tmp;
			u8_to_hex(&my_buf[9 + 2 * (i % 16)], tmp);
			//     1  +  2   +   4    +  2
			// 9 = ":" + "LL" + "AAAA" + "TT"
		} while (++i % 16 && i < len); //i % 16 - because, we use maximum 16 data bytes count for one string

		//if i == 16, i % 16 = 0, but tmp should be 16.
		tmp = i % 16 ? : 16; //tmp here store a byte count.
		u8_to_hex(&my_buf[1], tmp);

		checksum += tmp;
		checksum = 0x1u + ~checksum;
		//checksum calculation: summ = 1 + NOT(Val_1 + Val_2 + ... + Val_N)
		u8_to_hex(&my_buf[9 + 2 * tmp], checksum);
		my_buf[11 + 2 * tmp] = '\n';
		CDC_Transmit_FS((uint8_t*) my_buf, tmp * 2 + 12); //transmit buffer via CDC Device
	} while (i < len);
	CDC_Transmit_FS((uint8_t*) ":00000001FF\n", 12);
}

/* USER CODE BEGIN 4 */
/**
 * @brief  This function prints to USB CDC device an ihex array
 * this function use sprintf to make an output string
 * @retval none
 */
void print_to_ihex_pf(void *addr, uint32_t len) {
	//printing Extended Segment Address Record to ASCII codes
	uint16_t tmp = (uint16_t) (((uint32_t) addr) >> 16);
	uint8_t checksum = 0;
	sprintf(obuf, "\n:02000004%04X", tmp);
	checksum = 0x1u + ~(6u + (tmp >> 8 & 0xff) + (tmp & 0xff));
	sprintf(&obuf[14], "%X\n", checksum);
	CDC_Transmit_FS((uint8_t*) obuf, 17);

	//printing Data record to ASCII
	int i = 0;
	do {
		checksum = 0;
		sprintf(obuf, ":");
		//printing a segment address in ASCII at positions obuf[3..8]
		//obuf[1] and obuf[2] store byte count in ASCII
		tmp = (uint8_t) (((uint32_t) (addr + i)) >> 8);
		checksum += tmp;
		sprintf(&obuf[3], "%02X", tmp);

		tmp = (uint8_t) ((uint32_t) (addr + i));
		checksum += tmp;
		sprintf(&obuf[5], "%02X", tmp);

		tmp = 0x0u;
		checksum += tmp;
		sprintf(&obuf[7], "%02X", tmp);

		//printing HEX bytes in ASCII (positions obuf[9...]
		do {
			tmp = *(((uint8_t*) addr) + i);
			checksum += tmp;
			sprintf(&obuf[9 + 2 * (i % 16)], "%02X", tmp);
			//     1  +  2   +   4    +  2
			// 9 = ":" + "LL" + "AAAA" + "TT"
			//: - start symbol (1 bytes), LL - Length (2 bytes),
			//AAAA - Address (4 bytes), TT - Type (2 bytes)
			//2 * (i % 16) - bytes count in ASCII symbols.
			//In ASCII codes every BYTE is represented by two symbols
		} while (++i % 16 && i < len); //i % 16 - because, we use maximum 16 data bytes count for one string

		//if i == 16, i % 16 = 0, but tmp should be 16.
		tmp = i % 16 ? : 16; //tmp here store a byte count.
		char cnt[3]; //temporary char array to hold data bytes count in ASCII codes
		sprintf(cnt, "%02X", tmp); //printing bytes (Data) count to ASCII
		//obuf[1..2] stores a value of data bytes count in ASCII
		obuf[1] = cnt[0];  //copy first ASCII code at position 1
		obuf[2] = cnt[1]; //copy second ASCII code at position 2
		//we do not need to copy cnt[2], because it is a '\0'

		checksum += tmp;
		checksum = 0x1u + ~checksum;
		//checksum calculation: summ = 1 + NOT(Val_1 + Val_2 + ... + Val_N)
		sprintf(&obuf[9 + 2 * tmp], "%02X\n", checksum); //printing checksum to output buffer
		CDC_Transmit_FS((uint8_t*) obuf, tmp * 2 + 12); //transmit buffer via CDC Devise

	} while (i < len);

	sprintf(obuf, ":00000001FF\n");
	CDC_Transmit_FS((uint8_t*) obuf, 12);

}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
