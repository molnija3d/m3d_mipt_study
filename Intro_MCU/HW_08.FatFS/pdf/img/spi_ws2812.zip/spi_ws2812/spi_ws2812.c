/*
 * spi_ws2812.c
 *
 *  Created on: May 24, 2025
 *      Author: EZ-GPRO
 */
#include "spi_ws2812.h"
color_bit_t leds[LEDCNT];

void fill_color(uint16_t led_num, uint8_t bright, my_colors color) {
	/* 0xfc = 1
	 * 0xc0 = 0
	 * on 6 mbit/s 8-bit spi*/
	switch (color) {
	case C_ZERO:
		for (uint8_t j = 0; j < 8; j++) {
			leds[led_num].g[j] = 0xc0;
			leds[led_num].r[j] = 0xc0;
			leds[led_num].b[j] = 0xc0;
		}
		break;

	case C_RED:
		for (uint8_t j = 7 - bright; j < 8; j++) {
			leds[led_num].r[j] = 0xfc;
		}
		break;

	case C_GREEN:

		for (uint8_t j = 7 - bright; j < 8; j++) {
			leds[led_num].g[j] = 0xfc;
		}

		break;

	case C_BLUE:
		for (uint8_t j = 7 - bright; j < 8; j++) {
			leds[led_num].b[j] = 0xfc;
		}
		break;

	case C_RESET:
		for (uint8_t i = 0; i < LEDCNT; i++)
			for (uint8_t j = 0; j < 8; j++) {
				leds[i].g[j] = 0xc0;
				leds[i].r[j] = 0xc0;
				leds[i].b[j] = 0xc0;
			}
		break;
	}

}
