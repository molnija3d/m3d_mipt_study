/*
 * 7seglib.h
 *
 *  Created on: Jan 14, 2025
 *      Author: EZ-GPRO
 */
#include "stm32f4xx_hal.h"

#ifndef SEGLIB_H_
#define SEGLIB_H_

typedef struct{
	GPIO_TypeDef* port;
	uint16_t pin;

} pin_info;

typedef struct {
	pin_info A;
	pin_info B;
	pin_info C;
	pin_info D;
	pin_info E;
	pin_info F;
	pin_info G;
	pin_info P;
	pin_info Q1;
	pin_info Q2;
	pin_info Q3;
} MY_7SEG;

int my_7seg_init(MY_7SEG seg);
void my_7seg_disp_num(int num);
void my_7seg_disp_char(char letter, int pos);
void my_7seg_disp_anim(int num);


#endif /* SEGLIB_H_ */
