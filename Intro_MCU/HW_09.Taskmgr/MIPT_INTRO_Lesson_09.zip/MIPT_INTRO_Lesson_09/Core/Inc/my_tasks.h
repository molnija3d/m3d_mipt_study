/*
 * my_tasks.h
 *
 *  Created on: Feb 10, 2025
 *      Author: EZ-GPRO
 */

#ifndef INC_MY_TASKS_H_
#define INC_MY_TASKS_H_
#define MAX_TASKS (10)
#define Q_MAX (10)

#include "stdint.h"

typedef void (* task_t)();

typedef enum {
	TASK_FAIL = -1,
	TASK_OK,
	TASK_FULL
} tres_t;

typedef enum {
	Q_FAIL = -1,
	Q_OK,
	Q_RDY,
	Q_FULL,
	Q_NONE
} qres_t;

typedef struct {
	int data[Q_MAX];
	uint32_t q_len;
	uint32_t start;
	uint32_t end;
} queue_t;

tres_t task_add(task_t my_task);
void task_delay(uint32_t delay);
void tasks_start();

qres_t q_get(queue_t *qe, int *data);
qres_t q_put(queue_t *qe, int data);
qres_t q_check();

#endif /* INC_MY_TASKS_H_ */
